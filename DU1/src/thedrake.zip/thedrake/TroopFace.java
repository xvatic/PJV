package thedrake;

public final class TroopFace {
    public static final boolean AVERS  = true;
    public static final boolean REVERS = false;
    private TroopFace() {};
}

